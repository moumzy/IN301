double foo(int);
