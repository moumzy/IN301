#include <stdio.h>
#include "plam.h"
#include "plim.h"

int main(int argc,char **argv) {
  printf("%f %d\n",foo(4),bar(8));
  return 0;
}
