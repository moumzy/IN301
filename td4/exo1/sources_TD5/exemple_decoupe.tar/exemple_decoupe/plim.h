int bar(int);
